# Proposed scope decisions before B6

**Publication NOT READY / NOT CLEARED.** These counts describe the
[D5BG proposal](claims.json). The [run card](../../PUBLICATION_RUN_CARD.md)
retains the pending release gates.

| Claim disposition | Count |
| --- | ---: |
| READY | 3 |
| READY — QUALIFIED | 38 |
| ACTION REQUIRED | 12 |
| MAINTAINER DECISION | 14 |
| HISTORICAL ONLY | 4 |
| **Total proposed rows** | **71** |

The denominator includes 26 historical B4 primary IDs and 45 distinct splits
or later claim groups. All 18 subsystem pairs are mapped. The 67 rows outside
HISTORICAL ONLY reach **76 unique indispensable edges**. Of these, 41 have the
stated tracked route, 20 are conditional and 15 are held. Including all 71
rows gives **80** indispensable edges, with four held edges reached only from
historical rows. Shared package nodes and other transitive edges count once.
Supporting edges are outside those totals.

The [D5BH decision](../../DECISIONS.md#d5bh-d5as-first-release-evidence-tier--2026-11-08)
selects the existing D5AS ZIP for proposed complete-body comparison. Its
`ACTION REQUIRED` row describes the remaining exact staged and hosted checks.
The D5AS acquisition row retains the exact-replay hold. Attribute the original
qualification and eligibility to the reviewed historical investigation. The
selection calls for no additional custody package. Neither inherited
disposition count changes.

The maintainer selected the two local qualification routes in
[D5BO](../public-evidence-d5bo/README.md). D5AC-B2-RETAIL uses the bounded
attempt-002 event candidate. D5AG-FIXED-GEOMETRY uses the previously qualified
D5BJ geometry component with the exact separately supplied D5AS ZIP.
Both exact evidence edges remain HELD pending file-specific rights and
privacy decisions, approved transfer and retention, B6 and hosted-byte
verification. The 41 READY or READY — QUALIFIED rows retain their tiers.

The [D5BP decision matrix](../publication-decisions-d5bp/README.md#selected-evidence-tiers)
records the five selected narrower tiers for D5AT, E3, SD2 and position. The
corresponding five `MAINTAINER DECISION` rows still describe stronger
original replay. Their edges stay HELD and the counts above stand.
The [open-action crosswalk](../publication-decisions-d5bp/README.md#open-actions)
identifies the pending E3, SD2 and coordinate CORE witness checks. Exact D5AT
replay and the optional future VII-b live study are outside first-release
requirements. The selected D5AT tier uses tracked table arithmetic and
method with attributed historical fixed-input geometry.

The [D5BQ decision matrix](../publication-decisions-d5bq/README.md) confirms
the selected Save29 and Save52 CORE checks, the local output-link CORE
plus ADDENDUM checks and the exact Kreet callback derivative. It records the
four attributed historical-only choices separately. The bounded D1
saved-state tier is selected without a new historical asset. Its stronger
exact replay remains held. The graph counts above describe the inherited
rows and routes and carry forward.

## Decisions for the maintainer

1. Agree the N244 build and exact first-release wording, access tiers and
   separately qualified historical inputs. The recommended authored tier is
   the 41 READY or READY — QUALIFIED rows. Use the matrix wording and preserve
   the original research, reviews, failed controls and supersessions.
2. Confirm remaining selections among the 12 ACTION REQUIRED rows and
   qualify the selected D5AS-BODY, D5BP and D5BQ witness routes. Bind each selected
   route to its named reader and approved candidate members. The
   four proposed assets stay in the proposal. Use the existing staged inputs
   at B6. Where specified, the optional ADDENDUM is required for that claim's
   independent original-witness check.
3. Use the [actions ledger](actions.json) for unresolved tiers among the 14
   MAINTAINER DECISION rows. The five stronger D5BP routes and D1 exact
   saved replay remain separate future options. Other decisions include
   whether historical resource acquisition and causal claims beyond the selected D5BO routes need a
   bounded chronology or custody derivative. The separate D5AQ Option C
   and D5BJ/D5BM deferral record still governs that work.
4. Settle any residual contributor credit, excerpt and file-specific
   rights/privacy decisions on the actual proposed text and bytes. The project
   licence covers authored material where the contributors have rights.
   Existing proprietary and donor boundaries continue to apply.

The [D5BH episode audit](../evidence-derivative-d5bh/README.md) records the
bounded D5AK/D5AL local candidate and its limitations. Keep the exact public
episode routes held until file-specific clearance, agreed package transfer and
exact B6 review. The four D5BF asset entries below retain their own ledger.

The [D5BI N2 audit](../evidence-derivative-d5bi/README.md) records the selected
Option C local route. Keep both N2 evidence edges held pending file-specific
rights and privacy clearance, approved transfer and retention, exact B6 and
authorized hosting. The [D5BJ assessment](../evidence-reproduction-d5bj/README.md)
records the selected Option C work and remaining hold for the exact D5AQ fixture.

## Four local candidates

Each row is **APPROVED FOR PROPOSED RELEASE / PENDING RELEASE**.
The [D5BF exact ledger](../release-assets-d5bf/release-assets.json) controls
container/member SHA-256 values and the individual assessments. Current
distribution authorization is pending.

| Candidate basename | Exact scope and proposed joins |
| --- | --- |
| `sor-1.16.244.0-b4-f1-core-stored-provisional.zip` | 25 unchanged first-party saves. Member-level edges include named coordinate originals, Save29 ordered CB fields, Save52 topology and the selected HIST-0036 fabrication and fixture witnesses. |
| `sor-1.16.244.0-b4-f1-addendum-deflate-provisional.zip` | 14 unchanged saves and 13 original JPEGs. Required for the exact L-series, HIST-0021 display and named biome or placement original tiers where selected. Images establish only their specified visual evidence. |
| `d5as-feynman-geometry-v1.zip` | D5AS-BODY. Two fixed references and 30 qualified complete canonical sample bodies. Positions 7 and 13 match the mask-0 reference, and 28 match the mask-3 reference. The generating mask and winning request remain unobserved in the series. |
| `c19-callbacks-v1.json` | C19-CALLBACK. 346 recorded native callback comparisons with ordered inputs and row association. D1, 35,573 upstream evaluations, screen timing and full asynchronous ancestry are outside this payload. |

## Order of remaining work

1. Agree the claim matrix and evidence tiers. Close the actual selected
   blockers through the smallest approved action in the ledger. Keep
   optional gameplay and tooling extensions outside the freeze gate.
2. Under separate authorization, coordinate the archive design for
   implementation briefs and administrative audits. Account for membership,
   preserved names, discoverability, inbound links and history exposure.
   The [D5AX archive plan](../publication-architecture-d5ax/archive-plan.md)
   supplies the earlier design. Retain accessible original scientific reports
   and negative cases. The working directory may be discarded after
   publication under the [D5AW decision](../../DECISIONS.md#d5aw-local-working-evidence-and-publication-independence--2026-11-07).
3. Agree the exact release identity and tag policy, commit/tree, proposed
   public refs and reachable history, claim/build matrix, final rights
   disposition and staged asset bytes. Freeze that exact candidate and
   authorize isolated B6 preflight. Use a clean checkout without existing
   `.local-work/`, explicitly supplied staged assets, lawful prerequisites
   and the approved methods. Check the actual intended exposure and bind the
   independent B6 results to the frozen candidate.
4. After B6 acceptance and separate approval, perform only the exact approved
   Git, tag and draft-upload operations. Verify the real draft downloads,
   members, tag target and changed disclosure surfaces. Obtain separate
   visibility and timing approval before publication. Verify public
   downloads and reachable surfaces afterward.

## Catalogue reproduction

The documented read-only verifier passed at frozen D5BD source commit
`6e799a428a765aa196a24d3c1de8ae133260aa08` in a disposable tracked-source
export. It matched all 16 generated files and checked 325 distinct link
targets. The 2,095 entries comprise 18 Level A, 366 Level B and 1,711 Level C.
The same verifier on the newer D5BG candidate flagged stale coverage. An
in-memory comparison found that later audit documents add scan inputs and
change only generated `coverage.csv` and `locators.csv`. The other 14 files,
including the catalogue, alias and evidence tables, match.

The selected authored catalogue tier uses current tracked entries and original
locators. Exact reconstruction of the historical audit tables uses the frozen
source set. If the approved exposure omits that commit and exact rebuild is a
selected tier, qualify a standalone frozen source selection before advertising
it. No new native export or game input is needed for this text-only check.

## Review boundaries

The implementer compared both specialists' evidence distinctions against
original sources. In the physical/resource family, a saved descriptor and
conditional grid association can support the named position arithmetic
without proving retained-source membership, physical coverage or a generating
mask. D1's saved contrasts and the C19 callback fold cover different events.
In the systems family, Save29's order predicts a result from saved inputs
without identifying the historical worker invocation. Cargo's fuel-cycle
scheduling, saved registration and one-shot staging do not time a voyage.
The native catalogue challenge distinguishes an electrical queue promotion
from its older discovery interpretation and a scheduler instruction from
its containing function.

The local exact-snapshot delivery manifest and independent reviewer return
carry the actual checks and disposition. The text checker validates structure
and tier consistency. It does not establish historical replay, package custody,
hosted availability or permission to release. The original evidence and its
reviews control scientific confidence throughout.
