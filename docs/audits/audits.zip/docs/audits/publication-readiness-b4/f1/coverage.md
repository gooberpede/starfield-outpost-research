# B4-F1 claim coverage and redundancy

Proposed binary access for the unchanged 26-row B1 scope, not scope approval or scientific reclassification. [File decisions](file-dispositions.csv) retain every original B4 ID; [machine matrix](coverage.csv) supplies exact core/addendum/withheld IDs and controlling report/review routes. Additional corpus mentioned below is not silently added to the original 71-file inventory. No new candidate appendix is needed.

## B4-C01 — Identity, membership and Workshop ownership

Core: B4-F029;B4-F030;B4-F031;B4-F032;B4-F033;B4-F034;B4-F035;B4-F036;B4-F037;B4-F038;B4-F039;B4-F040;B4-F041;B4-F042;B4-F043;B4-F044;B4-F045. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core S0–S7C and Save52 support ordinary root/owner transitions and 848-root counterexample; no exhaustive active ownership. Private manual network remains unavailable.

[Report](../../../experiments/workshop-membership/report.md); [independent review](../../../experiments/workshop-membership/review.md)

## B4-C02 — Planetary location and position

Core: B4-F001;B4-F002;B4-F003;B4-F047;B4-F053. Addendum: B4-F009;B4-F010. Local-only: B4-F004;B4-F005;B4-F006;B4-F007;B4-F008. Excluded: NONE.

Core Save37–39 and exact Save25/26 preserve controlled source-frame contrasts; addendum scanner/map are surface context only. Fresh-character recreation/landing precision unknown.

[Report](../../../experiments/coordinate-sufficiency/report.md); [independent review](../../../experiments/coordinate-sufficiency/review.md)

## B4-C03 — Nominal biomes and resource regions

Core: B4-F003;B4-F040;B4-F047. Addendum: B4-F012;B4-F013;B4-F049. Local-only: B4-F050. Excluded: NONE.

Core Save52, Save25 and held-out Save39 retain the actual tested named frames; addendum Save31/33 and HIST-0035 extend independent snapshot/frame coverage. Save37 is not the tested biome witness. HIST-0210 repeats named cells. Lawful maps remain external.

[Report](../../../experiments/outpost-biomes/report.md); [independent review](../../../experiments/outpost-biomes/review.md)

## B4-C04 — Inorganic production and nominal rates

Core: B4-F029;B4-F030;B4-F031;B4-F032;B4-F037;B4-F038;B4-F040. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core S2C -> S3/S3C plus S4/S4C and S6C -> S7/S7C test placement/link/deletion; Save52 preserves 63 extractor joins. Nominal rate is not throughput.

[Report](../../../experiments/inorganic-extractors/report.md); [independent review](../../../experiments/inorganic-extractors/review.md)

## B4-C05 — Organic production

Core: B4-F040. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core Save52 retains six greenhouse/Water paths; no saved husbandry or realized output claim. Definitions require lawful installed data.

[Report](../../../experiments/organic-facilities/report.md); [independent review](../../../experiments/organic-facilities/review.md)

## B4-C06 — Manufactured production

Core: B4-F040;B4-F064. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core HIST-0036 preserves 17-fabricator/14-resource-group detailed witness and producer paths. Full 105-positive-save/1190-row corpus remains local; Save52 is a different example.

[Report](../../../experiments/fabricators/report.md); [independent review](../../../experiments/fabricators/review.md)

## B4-C07 — Power and generator fuel

Core: B4-F029;B4-F030;B4-F054. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core Save29 supplies ordered CB allocation; S3/S3C add controlled solar/extractor state. Historical live three-load evidence is local; no universal convergence or writer safety.

[Report](../../../experiments/power/report.md); [independent review](../../../experiments/power/review.md)

## B4-C08 — Storage and local output links

Core: B4-F032;B4-F040;B4-F044;B4-F045;B4-F064. Addendum: B4-F055;B4-F056;B4-F057;B4-F058;B4-F059. Local-only: B4-F065;B4-F066. Excluded: NONE.

Core H36/Save52 stocks and owner joins plus S-series construction/link transitions; addendum full L0C–L2C unlink/relink controls, anchored by core S4C=L0. H77/H83 comparisons remain local.

[Report](../../../experiments/storage/report.md); [independent review](../../../experiments/storage/review.md)

## B4-C09 — Cargo configuration, freight and inter-system fuel

Core: B4-F040. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core Save52 retains reciprocal pairs/stock/fuel-source joins. Private network JSON, original live timers, voyage durations and event captures remain local/unmeasured.

[Report](../../../experiments/cargo-links/transport/report.md); [independent review](../../../experiments/cargo-links/transport/review.md)

## B4-C10 — Crew, skills and robots

Core: B4-F040;B4-F051. Addendum: B4-F048. Local-only: NONE. Excluded: NONE.

Core H255 retains Lin/Heller assignments/ranks and robot examples; addendum H24 supplies distinct Vasco ship ranks. Saved rank does not measure post-load eligibility/output.

[Report](../../../experiments/crew-lifecycle/report.md); [independent review](../../../experiments/crew-lifecycle/review.md)

## B4-C11 — Construction limits, placement, variants and catalogue

Core: B4-F029;B4-F030;B4-F031;B4-F032;B4-F033;B4-F034;B4-F035;B4-F036;B4-F037;B4-F038;B4-F039;B4-F041;B4-F042;B4-F043;B4-F044;B4-F045;B4-F051. Addendum: B4-F011;B4-F012;B4-F013;B4-F014;B4-F015;B4-F016;B4-F017;B4-F018;B4-F019;B4-F020;B4-F021;B4-F023;B4-F025;B4-F026;B4-F027. Local-only: B4-F022;B4-F024. Excluded: NONE.

Core action/no-action chain plus H255 variants; addendum both complete L3 triplets and restriction/collision/preview images. No paired CHANGE/reload or photographed rock identity.

[Report](../../../experiments/build-catalogue/report.md); [independent review](../../../experiments/build-catalogue/review.md)

## B4-C12 — Attacks, defenses and Integrity

Core: B4-F051. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core H255 retains five damaged devices and owners; no save identifies an attacker or measures frequency. Scripts/native mechanism require lawful installation.

[Report](../../../experiments/outpost-defense/report.md); [independent review](../../../experiments/outpost-defense/review.md)

## B4-C13 — Chests, displays and mannequins

Core: B4-F040;B4-F051;B4-F064. Addendum: B4-F067. Local-only: B4-F065;B4-F066. Excluded: NONE.

Core H36/H255/Save52 comparisons plus addendum H21 helmet slot/backlink. H77/H83 and mannequin H256/H257 remain local; missing component receipts still prevent whole historical replay.

[Report](../../../experiments/containers-displays/report.md); [independent review](../../../experiments/containers-displays/review.md)

## B4-C14 — Shared Outpost Storage and crafting sources

Core: B4-F040;B4-F051;B4-F064. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core H36/H255/Save52 retain representative fixture/base/owner joins. 124-positive/1499-base census and actual backing quantity/spending are not reproduced by these three saves.

[Report](../../../experiments/shared-outpost-storage/report.md); [independent review](../../../experiments/shared-outpost-storage/review.md)

## B4-C15 — Stored Resources

Core: NONE. Addendum: B4-F062;B4-F063. Local-only: NONE. Excluded: NONE.

No binary is required for static provider explanation. Addendum two UI images give different inventory appearance; screenshot/save/cache epoch join UNKNOWN; original stock evidence elsewhere is scoped.

[Report](../../../experiments/stored-resources/report.md); [independent review](../../../experiments/stored-resources/review.md)

## B4-C16 — Locations to Outpost information

Core: NONE. Addendum: B4-F062;B4-F063. Local-only: NONE. Excluded: NONE.

No binary is required for field-to-provider explanation. Addendum F062/F063 preserve one/mature UI contrast; registry counts do not prove exhaustive membership or atomic refresh.

[Report](../../../experiments/locations-outpost/report.md); [independent review](../../../experiments/locations-outpost/review.md)

## B4-C17 — Identity

Core: B4-F040;B4-F042;B4-F043. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core Save52 plus S1/S1C preserve population and ordinary beacon contrast; retained canonical assembly ownership remains unresolved.

[Population](../../../experiments/workshop-population/report.md); [review](../../../experiments/workshop-population/review.md); [sources](../../../experiments/workshop-population/sources.csv)

## B4-C18 — Position

Core: B4-F001;B4-F002;B4-F003;B4-F047;B4-F053. Addendum: B4-F009;B4-F010. Local-only: B4-F004;B4-F005;B4-F006;B4-F007;B4-F008. Excluded: NONE.

Core geography controls give saved arithmetic. Addendum Lab range/map adds visual context; other frozen position originals and raw capture replay remain local; no continuous subcell/3D equivalence.

[Consolidation](../../../position-model/specification.md); [review](../../../position-model/review.md); [capability/evidence register](../../../position-model/capabilities.md)

## B4-C19 — Availability/deposits

Core: B4-F029;B4-F030;B4-F037;B4-F040. Addendum: NONE. Local-only: B4-F046;B4-F068;B4-F069;B4-F070;B4-F071. Excluded: NONE.

Core S3/S3C/S7 plus Save52 retain positive/control producer state. All D1 older snapshots remain local, including header-rejected H249; exact historical incident comparison unavailable. No cause/vein boundary result added.

[Output contract](../../../experiments/native-availability-map/output-contract.md); [review](../../../experiments/native-availability-map/output-review.md); [pins](../../../experiments/native-availability-map/sources.csv); [D1](../../../experiments/disappearing-deposits/report.md); [review](../../../experiments/disappearing-deposits/review.md); [pins](../../../experiments/disappearing-deposits/saves.csv)

## B4-C20 — Rate arithmetic

Core: NONE. Addendum: B4-F062;B4-F063. Local-only: NONE. Excluded: NONE.

Static nominal interval and binary32 arithmetic use published operands/lawful definitions; no core save is needed. Addendum nominal UI screens contextualize formatting; no actual throughput.

[E1 arithmetic](../../../experiments/inorganic-extractors/arithmetic-report.md); [review](../../../experiments/inorganic-extractors/arithmetic-review.md); [pins](../../../experiments/inorganic-extractors/arithmetic-sources.csv); [intervals](../../../experiments/inorganic-extractors/resource-intervals.md); [review](../../../experiments/inorganic-extractors/resource-intervals-review.md); [BM2 sum](../../../experiments/build-catalogue/production.md); [review](../../../experiments/build-catalogue/review.md); [pins](../../../experiments/build-catalogue/sources.csv)

## B4-C21 — Power

Core: B4-F054. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core Save29 retains exact allocation check; live repeated-load log remains local and native dependencies external. Writer NO-GO retained.

[Save29 authority](../../../experiments/power/save29-authority.md); [review](../../../experiments/power/save29-authority-review.md)

## B4-C22 — Local movement

Core: B4-F032;B4-F040;B4-F064. Addendum: B4-F055;B4-F056;B4-F057;B4-F058;B4-F059. Local-only: B4-F065;B4-F066. Excluded: NONE.

Core H36 finite 246-edge/18-join/nine-edge reread is distinct from addendum L-series 19->12->19 intervention. H77/H83 omitted originals prevent their exact checks.

[S2](../../../experiments/local-output-links/report.md); [review](../../../experiments/local-output-links/review.md); [pins](../../../experiments/local-output-links/sources.csv)

## B4-C23 — Cargo

Core: B4-F040. Addendum: NONE. Local-only: NONE. Excluded: NONE.

Core Save52 supplies exact cargo stock/pair joins, not flight timing or missed-stage replay. Private manual comparison and VM capture are withheld.

[C1](../../../experiments/cargo-links/configuration-ui/report.md); [review](../../../experiments/cargo-links/configuration-ui/review.md); [pins](../../../experiments/cargo-links/configuration-ui/sources.csv); [transit](../../../experiments/cargo-links/transport/transit.md); [review](../../../experiments/cargo-links/transport/transit-review.md); [C3](../../../experiments/cargo-links/fuel/report.md); [review](../../../experiments/cargo-links/fuel/review.md); [pins](../../../experiments/cargo-links/fuel/sources.csv)

## B4-C24 — Crew/robots

Core: B4-F051. Addendum: B4-F048. Local-only: NONE. Excluded: NONE.

Core H255 plus addendum H24 preserve rank/assignment distinctions; additional historical/generic/robot sample corpus stays local. Definition grants are not active buckets.

[CR1](../../../experiments/crew/report.md); [review](../../../experiments/crew/review.md); [current-assignment review](../../../experiments/crew/current-review.md); [pins](../../../experiments/crew/sources.csv); [CR2](../../../experiments/crew-skills/report.md); [review](../../../experiments/crew-skills/review.md); [pins](../../../experiments/crew-skills/sources.csv); [R1](../../../experiments/robots/report.md); [review](../../../experiments/robots/review.md); [pins](../../../experiments/robots/sources.csv)

## B4-C25 — Construction

Core: B4-F029;B4-F030;B4-F031;B4-F032;B4-F033;B4-F034;B4-F035;B4-F036;B4-F037;B4-F038;B4-F039;B4-F041;B4-F042;B4-F043;B4-F044;B4-F045;B4-F051. Addendum: B4-F011;B4-F012;B4-F013;B4-F014;B4-F015;B4-F016;B4-F017;B4-F018;B4-F019;B4-F020;B4-F021;B4-F023;B4-F025;B4-F026;B4-F027. Local-only: B4-F022;B4-F024. Excluded: NONE.

Core full S-chain and H255; addendum L3 complete POI/clutter sequences with both intermediate checkpoints and selected visual contrasts. No new no-action L3 save, exact rock/save join or rendered reload.

[L1](../../../experiments/limits/report.md); [review](../../../experiments/limits/review.md); [pins](../../../experiments/limits/sources.csv); [L2](../../../experiments/build-budget/report.md); [review](../../../experiments/build-budget/review.md); [pins](../../../experiments/build-budget/sources.csv); [L3](../../../experiments/spatial-placement/report.md); [review](../../../experiments/spatial-placement/review.md); [pins](../../../experiments/spatial-placement/sources.csv); [BM1](../../../experiments/construction-variants/report.md); [review](../../../experiments/construction-variants/review.md); [pins](../../../experiments/construction-variants/sources.csv)

## B4-C26 — Access and interfaces

Core: NONE. Addendum: NONE. Local-only: NONE. Excluded: NONE.

No raw save is required for declarations/consumer explanation; B3 maintained/archival methods and lawful inputs remain routes. Historical runtime-call captures stay local.

[RC1 ](../../outpost-rc1-2026-10/report.md); [review ](../../outpost-rc1-2026-10/review.md); [pins ](../../outpost-rc1-2026-10/sources.md); [Papyrus ](../../outpost-rc1-2026-10/papyrus-interfaces.md)

Without binary evidence, readers can inspect authored arguments, tables and B3 method sources and recreate static analysis from independently obtained lawful pinned game inputs. They cannot verify exact original save counts, unseen events or private whole-corpus results. Binary inclusion itself does not provide missing pipeline configuration, private network JSON, historical runtime state or missing component receipts.
