# D5BZ migration and method

Git HEAD at intake was d5ab299a5103b6d8d9f00c536f7cef455648cddb, with tree
1d0fa968c4e606fda7b3ba33636dda3d0f66c6b5. The index SHA-256 was
d10b8474c83ded331c73b8b6c01037c24917a99b049c0adfcfba2dca28ee7fe1.
Caller-available C and D bytes were 88,177,754,112 and 73,963,741,184.
Use the established two-drive 40,000,000,000-byte guard on guarded reads.
The original saves, evidence ZIPs, baseline assets and receipts are input
only. Archive builders read the exclusive ignored intake snapshot and
write two documentation containers and their indices. Historical
instructions inside the archives have no prospective execution authority.

The member CSVs are the original-path census. Git blob fields identify
pre-migration index entries. Worktree SHA-256 and size cover exact archived
bytes, including the untracked governing brief and the final pre-seal
records. Each active destination has a separate source record with original
and current digests. Historical metadata paths in frozen JSON are read
through an explicit map. The current file must exist with the documented
identity. Historical-only citations can resolve through a named ZIP member.
Changed pinned tracked sources use the exact baseline Git object for
historical pin comparison and the current manifest for current validation.

| Guidance examined | Applied control |
| --- | --- |
| Standing orders, workflow, permissions, charter and third-party policy | Scope limited to local documentation and selected reader changes. Source history, permissions, notices and credits are preserved. |
| Evidence standard and research state | Preserve scoped claims, counterexamples, historical verdicts, address domains and status. Use current guide/reference paths for ordinary use. |
| Research execution protocol, completion contract, reviewer procedure and editorial standard | Track the original four questions, preserve failures and require separate exact pre-seal and post-seal review. Treat structural screens and visual review separately. |
| Publication policy and run card | Bind final bytes and retain 7C history/exposure, custody, B6 and approval gates. Neither archive contents nor historical qualification establish distribution authority. |
| Save protection and D5BX access contracts | Use explicitly supplied lawful copies from the earlier rehearsal. Hash before and after. Retain complete derived outputs in exclusive ignored scratch. No game launch or native fixture execution. |
| D5AX architecture and D5BY navigation | Preserve original paths and make the archive index the historical entry. Keep RC1 technical data directly accessible and test subject journeys on the resulting tree. |
| B3, D5BG, D5BR, D5BU, D5BV, D5BF, D5BI, D5BW, D5BX and D5BS contracts | Preserve the original ledgers and pins, validate current operands and graph joins, and keep historical catalogue editions tied to their Git objects. |

Preview archives use stdlib ZIP Deflate level 9, path sort order, fixed
1980-01-01 00:00:00 ZIP time, MS-DOS archive attribute 0x20, ASCII paths,
regular file entries and empty per-entry and archive comments. Rebuild
comparison uses CPython 3.14.3 and zlib runtime 1.3.1.zlib-ng.
