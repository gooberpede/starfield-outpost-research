# D5BZ evidence access and custody

The current machine operands are enumerated in
research/archival/relocations.json and research/evidence-data/current-edition.json.
The active D5BF, D5BX and D5BI indexes retain their historical source bytes.
The selected B3, D5BG, D5BV and D5BY validator copies use explicit current
paths. The source crosswalk preserves both pre-migration and current hashes.

The isolation setup copies only candidate source files and omits the old
loose audit tree and private work. Workshop uses the exact v2 supplement,
F040/F042/F043 and the prior lawful staged ESM. Cargo uses F040 and the exact
C3 context. N2 uses the exact approved D5BI archive and relocated index.
These are existing local staged inputs. The candidate's access instructions
require explicit paths from the lawful supplier. The original comparison
receipts remain independent oracles and stay in local custody. The method
records the original input identities before and after each qualification batch.

At 7C bind the final source, archives, member indexes, reachable Git history,
all seven candidate assets and both supplements to the exact exposure
decision. Review historical path strings and derived metadata inside ZIP
members as well as the loose tree. Record the custodian, retention and
transfer decision for each required input. At B6 check a clean frozen tree
with separately authorized staged assets and exact reader scope. Validate
the planned lawful retrieval route and the conditional D5AG host. Hosting,
download verification and any visibility change remain separately gated.

## Isolated qualification results

The source-only copy contained no Git database, private work directory or
old audit subdirectory. The Workshop result matched its historical oracle
byte for byte at SHA-256
d6a5a32b632e96dabb6703244ba6b19cd343e7773795885a4b5bbf007380f55d.
The Cargo result matched at SHA-256
fdb2b73aeab8e18b0e5098367bedd63d391e26b0b2f10a3134decd67dcfcfcc6.
The Workshop archive and projection suite, N2 interpretation and adverse
controls, six synthetic framing tests and the C19 synthetic fold passed.
The pre/post receipt matched for all seven supplied inputs. Full receipts
remain in private local custody. No scientific claim or historical receipt
changed.
