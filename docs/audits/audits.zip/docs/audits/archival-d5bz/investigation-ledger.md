# D5BZ investigation ledger

The governing brief freezes four questions. The source census and current
mapping are keyed by the original path, with separate worktree and Git
identities. The local intake receipt captured 588 sources and 34,301,001
bytes, comprising 329 audit files and 259 implementation-brief files.
The brief was the only untracked intake path. The two replaced README
originals count as archive members.

| Question | Evidence and outstanding challenge at pre-seal |
| --- | --- |
| D5BZ-Q1 | Git index, untracked and ignored inventories were reconciled with an on-disk census. Both preview streams matched all original bytes. Freeze the task-created audit records after independent review and reconcile the final membership. |
| D5BZ-Q2 | Selected active ledgers moved with original bytes. Original method pins and validation receipts remain historical. Current D5BG and D5BV graph controls and B3 metadata checks passed. Source-only Workshop, Cargo and N2 execution and final-tree validation govern qualification. |
| D5BZ-Q3 | Current links were redirected to scientific authorities, active data or the exact archive lookup. RC1 mappings, B2 reader notation and B3 input contracts retain stable paths. Validate historical fragments and the selected reader journeys. |
| D5BZ-Q4 | The original index SHA-256 is recorded in the intake receipt. Both archive identities, final tree, exact patches, review and the 7C/B6 custody handoff require final verification. |

## Failures and corrections

- The archive builder first attempted to iterate the enclosing census
  object. It now reads the explicit source list and verifies both previews
  against the original bytes.
- The asset metadata check first joined the D5BW display identifiers
  directly to D5BV. D5BW carries three distinct D5BV identifiers. The
  corrected join uses the explicit crosswalk and checks all seven.
- The initial reader navigation check found private receipt links, one
  shortened stale fragment and whitespace in retained or new prose. The
  receipts are labelled private and the fragment now matches its exact
  heading. The corrected current check reported zero problems across
  671 Markdown files, 8,357 local links and 17 diagram structures.
- The first isolated method orchestration stopped before the original
  readers ran because the synthetic filename interpolation omitted the
  leading zero in F040, F042 and F043. The retry uses their exact basenames.

No release operation was performed. Publication remains
**NOT READY / NOT CLEARED**.
