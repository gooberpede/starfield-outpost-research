# D5BZ pre-seal independent review

**Disposition:** REWORK (first pre-seal review)

The independent reviewer compared both provisional ZIPs and indexes to the
intake snapshot. The 588 paths, 34,301,001 bytes, 587 Git blob identities and
the supplied untracked brief matched. The two trees contained zero ignored
files. The 44 selected relocation paths were unique and present. HEAD and
index matched intake. The seven protected input identities matched before
and after. The reviewer compared Workshop and Cargo receipts byte for byte
to their historical oracles, ran D5BG and D5BV controls, B3 and asset metadata
checks, and the D5BS technical edition. The reviewer found no terminal blocker.

| Criterion | Independent first-round result and required correction |
| --- | --- |
| AC01 | Strengthen applied-reading coverage and record the concrete effects. |
| AC02 | Intake census independently reconciled. Add task-created records and exact cutoff after pre-seal review. |
| AC03 | Preview names correct. Verify physical layout after removal. |
| AC04 | Exact preview bytes passed. Reject and test case-folded directory prefix collisions. Prove final safe extraction and rebuild. |
| AC05 | The governing brief is present and exact. Archive pre-seal history and attest final identity separately. |
| AC06 | Workshop and Cargo results match. Publish a current D5BF command and explain qualification of the shared selector for SD2 and construction. |
| AC07 | RC1 mapping and sampled scientific boundaries retained. Verify final prose and journeys. |
| AC08 | Status filter was empty and the human index grouped D5BX under an incidental ID. Correct status, ID and subject discovery. |
| AC09 | Metadata tests passed. Validate the explicit Workshop historical-to-current reader transition. |
| AC10 | Three pre-seal documents failed the authored line-ending check. Normalize them. Check final fragments, commands, journeys and diagrams. |
| AC11 | Exact binary patch verification is post-seal work. |
| AC12 | Scientific sampling found no fidelity defect. Engineering and editorial review returned REWORK. A fresh final review is required. |

All four questions remained INCOMPLETE at this stage. Review was read-only.

## Remediation submitted

The builder rejects different spellings of the same case-folded ancestor,
and the synthetic ZIP suite exercises the new refusal. Each CSV has subject,
record ID, original path, title and explicit historical status fields. Search
prints the recovered verdict. Both human indexes show subject groups. Brief
identifiers prioritize the governing record before the RG2 series label.
The D5BY review retains its final ACCEPT as well as the text of both prior
REWORK rounds in the original member.

The publication run card routes to the exact current D5BF command and lists
all seven assets and the two supplements. The asset check joins the distinct
D5BW historical Workshop reader to the D5BX projected entry and verifies the
original pin and current source manifest. Cargo retains its exact original
entry and current explicit inputs. The Workshop execution calls the same
changed D5BF ledger selector used by both SD2 and construction. It verifies
the full ledger digest and exercises three authenticated original selectors.
The relocation neither alters the other subcommands nor reruns their entire
scientific workloads.

The new authored records use UTF-8 and LF. Historical files preserve original
line endings inside ZIP members. Final editorial review, extraction, exact
patches and substantive acceptance remain separate post-seal checks.

## Second independent pre-seal review

**Disposition:** REWORK for AC08.

The reviewer confirmed exact intake preservation, portable extraction-name
refusal, the current B6 command, explicit Workshop reader transition, clean
authored audit records, and matching protection receipts and index. The
remaining lookup defects were the omitted scoped opening ACCEPT in the
D5BX review and the irrelevant default current reference for the D5BZ
governing brief. The index now preserves the scoped D5BX verdict and routes
D5BZ to the archive verification record.

## Independent pre-seal re-review

**Disposition:** ACCEPT for pre-seal review.

The reviewer verified that the index preserves the D5BX ACCEPT and its local
qualification scope and that the governing D5BZ brief points to the archive
verification record. All 588 preview members matched the intake bytes. All
173 current-source hashes matched the regenerated manifest. RC1 notation
edits are confined to the current reference. Final membership, safe extraction,
physical layout, binary patch reconstruction and fresh independent review
remain post-seal gates. Publication remains **NOT READY / NOT CLEARED**.
