# D5BZ reader journeys

The current reader layers preserve the three D5AX journeys and the eight
D5BY journeys. The common resource, power and identity journeys were
checked against both contracts. This record identifies the result and the
claim a reader must decline to infer.

| Contract and route | Scoped answer and stopping point |
| --- | --- |
| D5AX resource variation and D5BY deposit variation. Root, resource guide, technical page, D5AS series, exclusions and history. | Thirty qualified Feynman V starts split 2/28 between two reference-equivalent bodies. The tracked 28/196 and 168/196 mask census measures a different conditional domain. Neither measure identifies actual winners or general probabilities. |
| D5AX saved versus effective power and D5BY device state. Root, power guide, Save29 derivation, historical trial record and writer decision. | The saved bit describes prior state. The ordered graph supports scoped recalculation with a swap control. Repeated load chronology and safe writing remain unresolved or held. |
| D5AX owner versus UI and D5BY retained Hab. Root, identity guide, technical page, owner table and Workshop review. | 848 supported roots and 8,627 direct member records join across 19 owner rows. Canonical Hab origin and ordinary ownership remain unresolved. The 17/2 saved disabled split supplies no exhaustive active membership claim. |
| D5BY C19. Root history, research identifier, callback method and original review. | The derivative covers 346 ordered native callback comparisons. A synthetic fold exercises the reader. Upstream preview census and rendered timing retain separate status. |
| D5BY D5AG. Root history, research identifier, original review and fixed native stage. | Original Q1/Q4 completion coexists with Q2/Q3 and parent BLOCKED, ESCALATE and AC01 FAIL. The selected fixed stage requires the pinned asset, exact compatible host and lawful game files. |
| D5BY Cargo. Guide, technical reference, accepted fuel branch and worked model. | Five He-3 belongs to the accepted fuel cycle. Either-pad readiness and stage clocks are separate. Exact F040 and C3 verify selected saved joins and leave universal voyage timing unresolved. |
| D5BY independent verification. Root technical index, access tiers, exact assets, current methods and synthetic framing. | Six synthetic tests pass on invented operands. Original, projected and fixed native evidence have distinct supplied-file and host contracts. Pending asset status is visible. |
| D5BY display. Guide, technical reference, HIST-0021, F067 and original check. | A zero fixture inventory coexists with a saved positive helmet reference. The selected original check includes the backpack control and leaves rendered reload open. |

Historical navigation checks use exact member case and source fragments.
Command-path checks cover both archive READMEs, the B3 methods page, the
current evidence-data instructions, the evidence-access page and the
publication run card. The current D5BF command passed all four explicit
assets in the source-only copy. A missing relocated D5BF operand refused
despite exact old-path and private-work decoys. A one-byte operand change
also refused. The original operand was restored only in the owned test copy.

The D5BY structural checker recognizes 17 Mermaid flowcharts in the reader
surface. No local Mermaid renderer was available for visual qualification.
The run card retains the actual rendering check for the later B6 candidate.
